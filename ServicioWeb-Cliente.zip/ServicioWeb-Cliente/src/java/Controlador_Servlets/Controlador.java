/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador_Servlets;

import Modelo.Libro;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kevin
 */
@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
public class Controlador extends HttpServlet {
    
    //va a referenciar accion que se elija
    private String acceso ="";
    //variables para identificar cada o cada JSP
    private String index="index.jsp";
    private String insert="insert.jsp";
    private String modif="modif.jsp";
    
    Libro libro = new Libro ();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
          String accion =request.getParameter("accion");
            
            if(accion.equals("insert")){
                acceso = insert;
            }else if (accion.equals("Guardar")){
               String nombre = request.getParameter("nombre");
               String autor = request.getParameter("autor");
               int paginas = Integer.parseInt(request.getParameter("paginas"));
               String idioma = request.getParameter("idioma");
               String editorial = request.getParameter("editorial");
               
               libro.insetar(nombre, autor, paginas, idioma, editorial);
               acceso=insert;
            }else if(accion.equals("regresar")){
                acceso=index;
            }else if(accion.equals("delete")){
                int id = Integer.parseInt(request.getParameter("id"));
                libro.eliminar(id);
                acceso=index;
            }else if (accion.equals("modif")){
            acceso=modif;
            request.setAttribute("idModif", request.getParameter("id"));
            }else if (accion.equals("Modificar")){
               int id = Integer.parseInt(request.getParameter("txtid"));
               String nombre = request.getParameter("nombre");
               String autor = request.getParameter("autor");
               int paginas = Integer.parseInt(request.getParameter("paginas"));
               String idioma = request.getParameter("idioma");
               String editorial = request.getParameter("editorial"); 
               libro.modificar(id, nombre, autor, paginas, idioma, editorial);
              acceso=index;
            }
            //disparador para poder interactuar entre distintas clases
            RequestDispatcher dispatcher = request.getRequestDispatcher(acceso);
            dispatcher.forward(request, response);
        }
        
        
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        
        
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}


/*


    out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Controlador</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Controlador at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");


*/