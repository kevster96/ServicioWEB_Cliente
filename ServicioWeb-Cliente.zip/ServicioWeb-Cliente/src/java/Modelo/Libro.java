/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import webservice.LibroVO;

/**
 *
 * @author kevin
 */
public class Libro {
    
    public Libro(){
    }

    public  java.util.List<webservice.LibroVO> mostrar() {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.mostrar();
    }

    public LibroVO insetar(java.lang.String nombre, java.lang.String autor, int paginas, java.lang.String idioma, java.lang.String editorial) {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.insetar(nombre, autor, paginas, idioma, editorial);
    }

    public LibroVO eliminar(int id) {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.eliminar(id);
    }

    public LibroVO consultaID(int id) {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.consultaID(id);
    }

    public LibroVO modificar(int id, java.lang.String nombre, java.lang.String autor, int paginas, java.lang.String idioma, java.lang.String editorial) {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.modificar(id, nombre, autor, paginas, idioma, editorial);
    }
    
    
}
